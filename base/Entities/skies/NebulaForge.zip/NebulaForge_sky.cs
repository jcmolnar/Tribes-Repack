$xSky::Settings::Rotation = 0;
$xSky::Settings::Speed = 0;
$xSky::Settings::Haze = "40 48 59";
