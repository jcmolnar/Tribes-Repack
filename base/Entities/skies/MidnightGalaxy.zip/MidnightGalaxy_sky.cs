$xSky::Settings::Rotation = 0;
$xSky::Settings::Speed = 0;
$xSky::Settings::Haze = "34 53 92";
