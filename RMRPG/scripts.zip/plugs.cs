//exec(kadmos);
//exec(hsofiv);