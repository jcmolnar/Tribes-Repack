//////////////////////////////////////////////////////////////////
//								//
// File:		XMEN.VOL				//
// Version:		1.0					//
// Author: 		THZ*BlackjackDTM (Ryan Snook)		//					
// THZ Address:		http://thz.tsx.org			//
// Author Home Page:	http://snooknet.tsx.org	 		//
// E-mail:		ryan.traci@gte.net			//
//								//
// XMEN Web Address:	http://www.wheres.com/tribes/xmen	//
//								//
//////////////////////////////////////////////////////////////////

Install -
To install, drop in the Tribes\Base\Skins folder.


Thanks -
Thanks to Dynamix and everybody who loves to play Tribes.


Visit -
http://www.wheres.com/etc/icqskins for Tribes themed Icq Skins.

For -
To my friends the XMEN, I hope you enjoy these skins as THZ* has
 enjoyed your friendship.